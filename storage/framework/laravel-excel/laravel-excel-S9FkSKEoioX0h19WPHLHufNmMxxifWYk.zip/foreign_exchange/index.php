<?php $page = "home"; ?>
<?php include('inc_header.php');?>
<!-- middle -->
<div id="middle-content" class="homePage">
	<section id="banner_home" class="section fit_height">
    <div class="title_foreign">
      <h3>FOREIGN EXCHANGE</h3>
    </div>
    <div class="table_exhchange">
      <table>
        <tr class="bg_gradgrey">
          <td>&nbsp;</td>
          <td colspan ="2"><span class="title">TT</span><span class="smallTitle">(Telegraphic Transfer)</span></td>
          <td colspan ="2"><span class="title">Bank Notes</span></td>
        </tr>
        <tr class="bg_bluegrad">
          <td>&nbsp;</td>
          <td><span class="title">Bank Sell</span></td>
          <td><span class="title">Bank Buy</span></td>
          <td><span class="title">Bank Sell</span></td>
          <td><span class="title">Bank Buy</span></td>
        </tr>
        <tr>
          <td class="flag">
            <img src="images/material/usd.png">
            <span>USD</span>
          </td>
          <td class="bgopcity"><span class="rupiah">Rp.14.000,-</span></td>
          <td class="bgopcity"><span class="rupiah">Rp.15.000,-</span></td>
          <td class="bgopcity"><span class="rupiah">Rp.14.000,-</span></td>
          <td class="bgopcity"><span class="rupiah">Rp.15.000,-</span></td>
        </tr>
        <tr>
          <td class="flag">
            <img src="images/material/eur.png">
            <span>Eur</span>
          </td>
          <td class="bgopcity"><span class="rupiah">Rp.14.000,-</span></td>
          <td class="bgopcity"><span class="rupiah">Rp.15.000,-</span></td>
          <td class="bgopcity"><span class="rupiah">Rp.14.000,-</span></td>
          <td class="bgopcity"><span class="rupiah">Rp.15.000,-</span></td>
        </tr>
        <tr>
          <td class="flag">
            <img src="images/material/jpy.png">
            <span>JPY</span>
          </td>
          <td class="bgopcity"><span class="rupiah">Rp.14.000,-</span></td>
          <td class="bgopcity"><span class="rupiah">Rp.15.000,-</span></td>
          <td class="bgopcity"><span class="rupiah">Rp.14.000,-</span></td>
          <td class="bgopcity"><span class="rupiah">Rp.15.000,-</span></td>
        </tr>

        <tr>
          <td class="flag">
            <img src="images/material/cny.png">
            <span>CNY</span>
          </td>
          <td class="bgopcity"><span class="rupiah">Rp.14.000,-</span></td>
          <td class="bgopcity"><span class="rupiah">Rp.15.000,-</span></td>
          <td class="bgopcity"><span class="rupiah">Rp.14.000,-</span></td>
          <td class="bgopcity"><span class="rupiah">Rp.15.000,-</span></td>
        </tr>
        <tr>
          <td class="flag">
            <img src="images/material/aud.png">
            <span>AUD</span>
          </td>
          <td class="bgopcity"><span class="rupiah">Rp.14.000,-</span></td>
          <td class="bgopcity"><span class="rupiah">Rp.15.000,-</span></td>
          <td class="bgopcity"><span class="rupiah">Rp.14.000,-</span></td>
          <td class="bgopcity"><span class="rupiah">Rp.15.000,-</span></td>
        </tr>

        <tr>
          <td class="flag">
            <img src="images/material/sgd.png">
            <span>SGD</span>
          </td>
          <td class="bgopcity"><span class="rupiah">Rp.14.000,-</span></td>
          <td class="bgopcity"><span class="rupiah">Rp.15.000,-</span></td>
          <td class="bgopcity"><span class="rupiah">Rp.14.000,-</span></td>
          <td class="bgopcity"><span class="rupiah">Rp.15.000,-</span></td>
        </tr>

        <tr>
          <td class="flag">
            <img src="images/material/hkd.png">
            <span>HKD</span>
          </td>
          <td class="bgopcity"><span class="rupiah">Rp.14.000,-</span></td>
          <td class="bgopcity"><span class="rupiah">Rp.15.000,-</span></td>
          <td class="bgopcity"><span class="rupiah">Rp.14.000,-</span></td>
          <td class="bgopcity"><span class="rupiah">Rp.15.000,-</span></td>
        </tr>

        <tr>
          <td class="flag">
            <img src="images/material/myr.png">
            <span>MYR</span>
          </td>
          <td class="bgopcity"><span class="rupiah">Rp.14.000,-</span></td>
          <td class="bgopcity"><span class="rupiah">Rp.15.000,-</span></td>
          <td class="bgopcity"><span class="rupiah">Rp.14.000,-</span></td>
          <td class="bgopcity"><span class="rupiah">Rp.15.000,-</span></td>
        </tr>
      </table>

    </div>
  </section>
</div>
<!-- end of middle -->
<?php include('inc_footer.php');?>