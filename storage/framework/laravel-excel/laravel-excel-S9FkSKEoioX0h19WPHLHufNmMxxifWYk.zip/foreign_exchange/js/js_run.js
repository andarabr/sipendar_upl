/*===============================================================================================================	
Author     : Muhammad Febriansyah
Date       : November 2016
 =============================================================================================================== */
$(document).ready(function() {
	$('.scroll-pane').jScrollPane();
	$("#Regform").validate();
	windowHeight();

	$(".trigger_page").click(function(e){
		e.preventDefault();
		var targetPage = $(this).attr("href");
		$(".stepBanner").addClass("hide");
		$(targetPage).show();
	});
	$('.equalize').equalize();

	var width = $(window).width();
	if (width > 1023){
 		$('.same-height').sameHeight();
		$(window).resize(function(){
		    // Do it when the window resizes too
		    $('.same-height').sameHeight();
		});
	};
	
});

