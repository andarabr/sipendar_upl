/*===============================================================================================================	
Author     : Muhammad Febriansyah
Date       : Mei 2016
 =============================================================================================================== */

 $.fn.generate_height = function () {
  var maxHeight = -1;
  $(this).each(function () {
    $(this).children().each(function () {
      maxHeight = maxHeight > $(this).height() ? maxHeight : $(this).height();
    });

    $(this).children().each(function () {
      $(this).height(maxHeight);
    });
  })
}

function windowHeight(){
	$(window).bind("load resize",function(){
		$(".fit_height").height($(window).height());	
	});
	$(window).bind("load resize",function(){
		if ($(window).width() > 789) {
			$(".half_height").height($(window).height()/2);
		}else{
			$(".half_height").height($(window).height());	
		}
	});

    $(window).bind("load resize",function(){
        $(".frameHeight").height($(window).height());  
        $(".frameHeight").width($(window).width());    
    });
}

$.fn.equalize = function() {
	var maxHeight = 0;
	
	return this.each(function(){
		var $this = $(this);
		
		if ($(this).height() > maxHeight) { maxHeight = $(this).height(); }
		
		$this.height(maxHeight);
        });
};

 // the sameHeight functions makes all the selected elements of the same height
$.fn.sameHeight = function() {
    var selector = this;
    var heights = [];

    // Save the heights of every element into an array
    selector.each(function(){
        var height = $(this).height();
        heights.push(height);
    });

    // Get the biggest height
    var maxHeight = Math.max.apply(null, heights);
    // Show in the console to verify
    console.log(heights,maxHeight);

    // Set the maxHeight to every selected element
    selector.each(function(){
        $(this).height(maxHeight);
    }); 
};
